# ForgeJS Plugins Authors List

##### Please add entries to the bottom of the list in the following format
* `@GitHub UserName (Required) - [Name and/or Organization](link)`

# Authors
* @rroux-gpsw - [GoPro, Inc.](https://forgejs.org)
* @ygilquin-gpsw - [GoPro, Inc.](https://forgejs.org)
* @bbaudel-gpsw - [GoPro, Inc.](https://forgejs.org)
* @aberthet-gpsw - [GoPro, Inc.](https://forgejs.org)

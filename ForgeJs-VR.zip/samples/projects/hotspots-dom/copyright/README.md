# Copyright licenses

## Image files

Author: Floris Kloet<br/>
Website: http://www.livingstills.nl/<br/>
File: https://media.giphy.com/media/l0MYRbawhDAnyMG4w/giphy.gif<br/>
License: [Giphy Terms](https://giphy.com/terms)
License: [Creative Commons License 4.0 International](https://creativecommons.org/licenses/by/4.0/deed)<br/>
![Creative Commons License 4.0 International](https://i.creativecommons.org/l/by/3.0/nl/88x31.png)<br/>
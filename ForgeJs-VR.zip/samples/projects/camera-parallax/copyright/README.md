# Copyright licenses

## Image files

Author: Dominik Baumann<br/>
Website: http://www.dominik-baumann.at/<br/>
File: Innerschweiz-no-planes.jpg<br/>
License: [Creative Commons License 4.0 Attribution-NonCommercial-NoDerivatives 4.0 International](https://creativecommons.org/licenses/by-nc-nd/4.0/)<br/>
![Creative Commons License 4.0 Attribution-NonCommercial-NoDerivatives 4.0 International](https://i.creativecommons.org/l/by-nc-nd/3.0/nl/88x31.png)<br/>

Author: Dominik Baumann<br/>
Website: http://www.dominik-baumann.at/<br/>
File: plane-a912.png<br/>
License: [Creative Commons License 4.0 Attribution-NonCommercial-NoDerivatives 4.0 International](https://creativecommons.org/licenses/by-nc-nd/4.0/)<br/>
![Creative Commons License 4.0 Attribution-NonCommercial-NoDerivatives 4.0 International](https://i.creativecommons.org/l/by-nc-nd/3.0/nl/88x31.png)<br/>

Author: Dominik Baumann<br/>
Website: http://www.dominik-baumann.at/<br/>
File: plane-a915.png<br/>
License: [Creative Commons License 4.0 Attribution-NonCommercial-NoDerivatives 4.0 International](https://creativecommons.org/licenses/by-nc-nd/4.0/)<br/>
![Creative Commons License 4.0 Attribution-NonCommercial-NoDerivatives 4.0 International](https://i.creativecommons.org/l/by-nc-nd/3.0/nl/88x31.png)<br/>

Author: Dominik Baumann<br/>
Website: http://www.dominik-baumann.at/<br/>
File: plane-a917.png<br/>
License: [Creative Commons License 4.0 Attribution-NonCommercial-NoDerivatives 4.0 International](https://creativecommons.org/licenses/by-nc-nd/4.0/)<br/>
![Creative Commons License 4.0 Attribution-NonCommercial-NoDerivatives 4.0 International](https://i.creativecommons.org/l/by-nc-nd/3.0/nl/88x31.png)<br/>

Author: Dominik Baumann<br/>
Website: http://www.dominik-baumann.at/<br/>
File: plane-a919.png<br/>
License: [Creative Commons License 4.0 Attribution-NonCommercial-NoDerivatives 4.0 International](https://creativecommons.org/licenses/by-nc-nd/4.0/)<br/>
![Creative Commons License 4.0 Attribution-NonCommercial-NoDerivatives 4.0 International](https://i.creativecommons.org/l/by-nc-nd/3.0/nl/88x31.png)<br/>

Author: Dominik Baumann<br/>
Website: http://www.dominik-baumann.at/<br/>
File: plane-a928.png<br/>
License: [Creative Commons License 4.0 Attribution-NonCommercial-NoDerivatives 4.0 International](https://creativecommons.org/licenses/by-nc-nd/4.0/)<br/>
![Creative Commons License 4.0 Attribution-NonCommercial-NoDerivatives 4.0 International](https://i.creativecommons.org/l/by-nc-nd/3.0/nl/88x31.png)<br/>

Author: Dominik Baumann<br/>
Website: http://www.dominik-baumann.at/<br/>
File: plane-a933.png<br/>
License: [Creative Commons License 4.0 Attribution-NonCommercial-NoDerivatives 4.0 International](https://creativecommons.org/licenses/by-nc-nd/4.0/)<br/>
![Creative Commons License 4.0 Attribution-NonCommercial-NoDerivatives 4.0 International](https://i.creativecommons.org/l/by-nc-nd/3.0/nl/88x31.png)<br/>
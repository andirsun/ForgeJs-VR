# Copyright licenses

## Audio files

Author: TinyWorlds<br/>
Track: Forest Ambience<br/>
File: Forest_Ambience.mp3<br/>
License: [Creative Commons License 1.0 Universal Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/)<br/>
![Creative Commons License 1.0 Universal Public Domain Dedication](https://i.creativecommons.org/p/zero/1.0/88x31.png)<br/>

Author: Luftrum<br/>
Track: forestsurroundings<br/>
File: forestsurroundings.mp3<br/>
License: [Creative Commons License Attribution 3.0 Unported](https://creativecommons.org/licenses/by/3.0/)<br/>
![Creative Commons License Attribution 3.0 Unported](https://i.creativecommons.org/l/by/4.0/88x31.png)<br/>

Author: cynicmusic<br/>
Track: Battle theme A<br/>
File: battleThemeA.mp3<br/>
License: [Creative Commons License 1.0 Universal Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/)<br/>
![Creative Commons License 1.0 Universal Public Domain Dedication](https://i.creativecommons.org/p/zero/1.0/88x31.png)<br/>

Author: Sudocolon<br/>
Track: Space Ace<br/>
File: Logisector Intro.mp3<br/>
License: [Creative Commons License 1.0 Universal Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/)<br/>
![Creative Commons License 1.0 Universal Public Domain Dedication](https://i.creativecommons.org/p/zero/1.0/88x31.png)<br/>

Author: Oddroom<br/>
Track: Samsara<br/>
File: samsara_0.mp3<br/>
License: [Creative Commons License 1.0 Universal Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/)<br/>
![Creative Commons License 1.0 Universal Public Domain Dedication](https://i.creativecommons.org/p/zero/1.0/88x31.png)<br/>

Author: tebruno99<br/>
Track: The Rush<br/>
File: The Rush.mp3<br/>
License : [Creative Commons License 1.0 Universal Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/)<br/>
![Creative Commons License 1.0 Universal Public Domain Dedication](https://i.creativecommons.org/p/zero/1.0/88x31.png)<br/>
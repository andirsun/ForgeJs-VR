# Copyright licenses

## Images files

Author: Danko<br/>
Website: Unknown<br/>
File: clipart-friendly-rabbit-128x128-4854.png<br/>
License: [Creative Commons License 1.0 Universal Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/)<br/>
![Creative Commons License 1.0 Universal Public Domain Dedication](https://i.creativecommons.org/p/zero/1.0/88x31.png)<br/>

Author: Borboleta.org<br/>
Website: http://borboleta.org/<br/>
File: clipart-papilio-buddha-64x64-5c24.png<br/>
License: [Creative Commons License 1.0 Universal Public Domain Dedication](https://creativecommons.org/publicdomain/zero/1.0/)<br/>
![Creative Commons License 1.0 Universal Public Domain Dedication](https://i.creativecommons.org/p/zero/1.0/88x31.png)<br/>
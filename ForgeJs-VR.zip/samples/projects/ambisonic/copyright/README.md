# Copyright licenses

## Audio files

Author: Plan8.se<br/>
Track: Unknown<br/>
File: ambisonic.wav / 37b1fe960daba91fffadbdb5a3a9db15.wav<br/>
License: Unknown<br/>